﻿
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;
namespace RTSSanGuo.Data
{
    public class DSection:DBase
    {             
        public int id_leader;
        public List<int> id_cityList = new List<int>();
        public string shortDesc;
        public string fullDesc;

        
    }

}
