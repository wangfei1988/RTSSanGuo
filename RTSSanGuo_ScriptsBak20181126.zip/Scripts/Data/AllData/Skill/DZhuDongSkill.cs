﻿using System.Collections.Generic;
using UnityEngine;
using System.IO;
namespace RTSSanGuo.Data
{
    

    public class DZhuDongSkill:DBase
    {
        public string imgName;         
    }
    

}
