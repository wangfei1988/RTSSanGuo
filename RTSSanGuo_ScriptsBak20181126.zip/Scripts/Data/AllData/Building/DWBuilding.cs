﻿using System.Collections.Generic;
using UnityEngine;
using System.IO;
namespace RTSSanGuo.Data
{
    //这些可以new 出来也可以从csv加载进来
    public class DWBuilding
    { 
        public EWBuildingType type;
        public Vector3 pos;         
        public int curHP;
               
    }


}