﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.IO;
using UnityEngine;
namespace RTSSanGuo.Entity
{
   
   public  class EntityMgr
    {
        //这个其实不需要继承MonoBehavior，但是为了和GameObjManager统一，还是继承
        //对性能不会有多大影响
        public static EntityMgr _instance = new EntityMgr(); //这些在Awake之前执行
        public static EntityMgr Instance
        {
            get
            {
                return _instance;
            }
        }

         
    }
}
