﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace RtsFrameWork.Tool.FileTool
{
    public class PathTool
    {
        public static string AppRootFold {
            get { return ""; }
        }
        public static string DataFileRootFold
        {
            get { return ""; }
        }
        public static string ResRootFold
        {
            get { return ""; }
        }
        public static string BundleRootFold
        {
            get { return ""; }
        }          
    }
}
